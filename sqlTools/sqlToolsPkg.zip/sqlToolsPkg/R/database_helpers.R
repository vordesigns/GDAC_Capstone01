#' Run a non-query SQL command
#'
#' @param con A DBI connection object
#' @param query SQL command as a string (CREATE, INSERT, etc.)
#' @param label Optional label for logging
#' @return NULL, prints message
#' @export
run_query <- function(con, query, label = NULL) {
  tryCatch({
    result <- DBI::dbExecute(con, query)
    prefix <- if (!is.null(label)) paste0("[", label, "] ") else ""
    if (result == 0) {
      message(prefix, "Commands completed successfully.")
    } else {
      message(prefix, result, " rows affected.")
    }
  }, error = function(e) {
    message("Error: ", e$message)
  })
}

#' Fetch data from a SQL query
#'
#' @param con A DBI connection object
#' @param query SQL query as a string
#' @param label Optional label for logging
#' @return A data frame with the query results, or NULL on error
#' @export
fetch_data <- function(con, query, label = NULL) {
  tryCatch({
    df <- DBI::dbGetQuery(con, query)
    prefix <- if (!is.null(label)) paste0("[", label, "] ") else ""
    message(prefix, "Query executed. ", nrow(df), " rows returned.")
    return(df)
  }, error = function(e) {
    message("Error: ", e$message)
    return(NULL)
  })
}
